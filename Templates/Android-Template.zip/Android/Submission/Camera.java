

public class Camera{

	public int takePhoto(){
		return 1;
	}
	
}