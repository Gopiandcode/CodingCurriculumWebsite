If you are on windows, double click the batch file to compile the java files
If you are on Mac or Linux, open a terminal window and run this command: javac *.java
When the Filepicker appears Select these classes in order
AndroidNew.class
Camera.class