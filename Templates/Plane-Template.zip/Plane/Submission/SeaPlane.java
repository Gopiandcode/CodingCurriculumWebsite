import jane.the.programmer.Plane;

public class SeaPlane{

}