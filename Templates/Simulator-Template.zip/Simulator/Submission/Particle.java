

public class Particle {

	public double x,y;

	




	
	

}
