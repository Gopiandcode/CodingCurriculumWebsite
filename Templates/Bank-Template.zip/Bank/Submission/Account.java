
public class Account {

	public int money;
	

	
}