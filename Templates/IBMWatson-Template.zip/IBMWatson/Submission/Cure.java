

public class Cure{

	

}