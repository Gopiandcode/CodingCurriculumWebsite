

public class Symptom{
		String name;
		public Symptom(){
			name = "Test";
		}
		public String getName(){
			return name;
		}

}