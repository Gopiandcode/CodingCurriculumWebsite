

public class Symptom{
	

}