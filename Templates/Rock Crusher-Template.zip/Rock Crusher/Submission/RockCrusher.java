import jane.the.programmer.Stone;
import jane.the.programmer.Ruby;


public class RockCrusher{
	
	

}