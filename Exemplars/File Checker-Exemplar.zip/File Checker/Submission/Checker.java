import jane.the.programmer.DocFile;
import jane.the.programmer.ExeFile;


public class Checker{
	
	
	public boolean check(DocFile file){
		return true;
	}
	
	public boolean check(ExeFile file){
		return false;
	}
	
	
}