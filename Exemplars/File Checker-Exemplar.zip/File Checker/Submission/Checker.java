import jane.the.programmer.DocFile;
import jane.the.programmer.ExeFile;
import jane.the.programmer.Verifiable;
import jane.the.programmer.UnVerifiable;


public class Checker{
	
	
	public boolean check(DocFile file){
		return true;
	}
	
	public boolean check(ExeFile file){
		return false;
	}
	public boolean check(Verifiable file){
		return true;
	}
	
	public boolean check(UnVerifiable file){
		return false;
	}
	
	
}