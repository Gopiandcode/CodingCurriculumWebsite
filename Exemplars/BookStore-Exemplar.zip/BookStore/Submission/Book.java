
public class Book {

	public String title;
	public String color;
	public String author;
	public String genre;
	
	
}