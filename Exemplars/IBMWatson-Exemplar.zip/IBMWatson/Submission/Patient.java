

public class Patient{
		public Symptom symptoms = new Symptom();

}