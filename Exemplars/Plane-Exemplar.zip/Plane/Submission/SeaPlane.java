import jane.the.programmer.Plane;

public class SeaPlane extends Plane{

	WaterGear gear = new WaterGear();
		
	
}