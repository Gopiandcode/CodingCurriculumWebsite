import jane.the.programmer.*;

public class WaterGear extends LandingGear implements WaterProof{

	
	
}
