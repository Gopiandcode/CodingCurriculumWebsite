import jane.the.programmer.Stone;
import jane.the.programmer.Ruby;


public class RockCrusher{
	
	
	public void crush(Stone stone){
		stone.crush();
	}
	
	public void crush(Ruby stone){
		
	}
	
}